<?php
/*------------------------------------------------------------------------
 # com_joomslot - Component Slot Games For Joomla!
 # ------------------------------------------------------------------------
 * @version    CVS: 1.0.0
 * @package    Com_Joomslot
 * @author     Joomslot <admin@joomslot.com>
 * @copyright  Joomslot.com
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access
defined('_JEXEC') or die('Restricted access');
use \Joomla\CMS\Language\Text;

class pkg_JoomslotInstallerScript {
	
	public function __constructor(JAdapterInstance $adapter){
		
	}

	function postflight($type, $parent) 
    {
    	$db = JFactory::getDBO();

		$query = "update `#__extensions` set enabled=1 where type = 'plugin' and element = 'joomslotaccount' and folder='user'";
		$db->setQuery($query);
		$db->execute();

		$query = "update `#__extensions` set enabled=1 where type = 'plugin' and element = 'joomslotdemo' and folder='system'";
		$db->setQuery($query);
		$db->execute();

		$query = "update `#__extensions` set enabled=1 where type = 'plugin' and element = 'kennieclub' and folder='gppayment'";
		$db->setQuery($query);
		$db->execute();


		$query = "select count(*) from #__menu_types where menutype='joomslot'";
		$db->setQuery($query);
		$cnt = $db->loadResult();

		if($cnt==0){
		    $query = "insert into #__menu_types(`menutype`,`title`,`description`) values('joomslot','".JText::_('COM_JOOMSLOT_MENU_TYPE')."','joomslot menu')";
			$db->setQuery($query);
			$db->execute();

			$query = "select extension_id from `#__extensions` WHERE `element` = 'com_joomslot' AND `type` = 'component'";
			$db->setQuery($query);
			$extension_id = $db->loadResult();

			$params='{"menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_image_css":"","menu_text":1,"menu_show":1,"page_title":"","show_page_heading":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}';

			$menuinfo = array();

			$menuinfo[] = ["title"=> JText::_('COM_JOOMSLOT_MENU_GAMES'),"alias"=>"games","link"=>"index.php?option=com_joomslot&view=games"];
			$menuinfo[] = ["title"=> JText::_('COM_JOOMSLOT_MENU_PURCHASE'),"alias"=>"purchase","link"=>"index.php?option=com_joomslot&view=order"];
			$menuinfo[] = ["title"=> JText::_('COM_JOOMSLOT_MENU_WITHDRAW'),"alias"=>"withdraw","link"=>"index.php?option=com_joomslot&view=withdrawal"];
			$menuinfo[] = ["title"=> JText::_('COM_JOOMSLOT_MENU_PURCHASEHISTORY'),"alias"=>"purchase-history","link"=>"index.php?option=com_joomslot&view=orders"];
			$menuinfo[] = ["title"=> JText::_('COM_JOOMSLOT_MENU_WITHDRAWHISTORY'),"alias"=>"withdraw-history","link"=>"index.php?option=com_joomslot&view=withdrawals"];
			$menuinfo[] = ["title"=> JText::_('COM_JOOMSLOT_MENU_ACCOUNT'),"alias"=>"my-account","link"=>"index.php?option=com_joomslot&view=account"];
			$menuinfo[] = ["title"=> JText::_('COM_JOOMSLOT_MENU_POINTHISTORY'),"alias"=>"gamepoints-history","link"=>"index.php?option=com_joomslot&view=paydata"];
			$menuinfo[] = ["title"=> JText::_('COM_JOOMSLOT_MENU_GAMEHISTORY'),"alias"=>"game-history","link"=>"index.php?option=com_joomslot&view=gamedata"];

			$lft = 11;
			$rgt = 12;
			foreach($menuinfo as $menu){
				$query = "insert into #__menu (`menutype`,`title`,`alias`,`path`,`link`,`type`,`published`,`level`,`component_id`,`params`,`access`,`language`,`lft`,`rgt`) values('joomslot',".$db->quote($menu['title']).",".$db->quote($menu['alias']).",".$db->quote($menu['alias']).",".$db->quote($menu['link']).",'component',1,1,".$extension_id.",'".$params."',1,'*',$lft,$rgt)";
				$db = JFactory::getDBO();
				$db->setQuery($query);
				$db->execute();
				$lft=$lft+2; $rgt=$rgt+2;
			}
		}

		$this->showInstallMessage();
	}

	protected function showInstallMessage($messages=array()) {
		//$app			= JFactory::getApplication();
		//$isUpdateScreen = $app->input->get('option') == 'com_installer' && $app->input->get('view') == 'update';
	?>
	<div class="row-fluid">
		<h2>Joomslot - Component Slot Games For Joomla!</h2>
		<p>
			After component is installed you need to setup game provider URL and API key in component config section. Visit <a href="https://www.joomslot.com/faqs" target="_blank">joomslot.com</a> to get your API key.
		</p>
		<p>
			For payment and withdrawal you need to add credentials to kennieclub plugin and select it for withdrawal.
		</p>
	</div>
	<?php
	}
}
